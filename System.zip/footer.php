<?php 
    if(empty($_SESSION)):
        echo "<script>window.location.href='login/login.php';</script>";
    endif;
?>
		
		
  </div>
</div>
		<footer class="my-5 pt-5 text-muted text-center text-small">
		    <p class="mb-1">&copy; 2017-2020 MexClima</p>
		    
		</footer>

  </body>
</html>
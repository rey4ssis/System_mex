<?php
	
    include_once "classes/acesso.php";

	include 'header.php';


	include 'content.php';


	include 'footer.php';

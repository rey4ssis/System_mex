<?php 
    if(empty($_SESSION)):
        echo "<script>window.location.href='login/login.php';</script>";
    endif;
?>
<div class="container bg-light">
  <div class="row">
    <div class="py-5 text-center">
    <img class="mb-4" src="img/mex.svg" alt="" width="auto" height="200">
    <h2>Cadastros de serviços</h2>
    <p class="lead">Aqui será feito todo o cadastro do cliente, para melhor atendê-lo fale todos os detalhes do problema do seu aparelho</p>
  </div>
    
    <div class="col-md-8 order-md-1">
      <h4 class="mb-3">Informações</h4>
      <form class="needs-validation" novalidate>


        <div class="row"><!--Segundo Row-->
          <div class="col-md-6 mb-3">
            <label for="firstName">Nome</label>
            <input type="text" class="form-control" id="nome" value="" required name="nome">
            <div class="invalid-feedback">
              Valid first name is required.
            </div>
          </div>
          <div class="col-md-6 mb-3">
            <label for="lastName">Sobrenome</label>
            <input type="text" class="form-control" id="sobrenome" value="" required name="sobrenome">
            <div class="invalid-feedback">
              Valid last name is required.
            </div>
          </div>
        </div><!--Fim segundo Row-->

        <div class="mb-3">
          <label for="username">Apelido</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <span class="input-group-text"></span>
            </div>
            <input type="text" class="form-control" id="username" placeholder="Username" required name="apelido">
            <div class="invalid-feedback" style="width: 100%;">
              Your username is required.
            </div>
          </div>
        </div>

        <div class="mb-3">
          <label for="email">Email <span class="text-muted">(Optional)</span></label>
          <input type="email" class="form-control" id="email" placeholder="e-mail@example.com">
          <div class="invalid-feedback">
            Please enter a valid email address for shipping updates.
          </div>
        </div>

        <div class="mb-3">
          <label for="address">Celular</label>
          <input type="Tel" class="form-control" id="address" required placeholder="(00) 0 0000-0000">
          <div class="invalid-feedback">
            Please enter your shipping address.
          </div>
        </div>

        <div class="mb-3">
          <label for="address2">Telefone <span class="text-muted">(Optional)</span></label>
          <input type="Tel" class="form-control" id="address2">
        </div>

        <div class="row"> <!--Terceiro Row-->
          <div class="col-md-5 mb-3">
            <label for="country">Localidade</label>
            <input type="text" class="form-control" id="address2" name="cidade">
            <div class="invalid-feedback">
              Please select a valid country.
            </div>
          </div>
          <div class="col-md-4 mb-3">
            <label for="state">Rua</label>
            <input type="text" class="form-control" id="address2" name="Rua">
            <div class="invalid-feedback">
              Please provide a valid state.
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <label for="zip">Nº</label>
            <input type="text" class="form-control" id="zip" placeholder="" required name="n_casa">
            <div class="invalid-feedback">
              Zip code required.
            </div>
          </div>
        </div><!--Fim terceiro Row-->
        <hr class="mb-4">
      
        <hr class="mb-4">

        <h4 class="mb-3">Relatório dos problemas</h4>

        <div class="mb-3">

          <div class="row">
            <div class="col-md-6">
              <label for="address">Qual o tipo do aparelho ?</label>
              <input type="Tel" class="form-control" id="address" required name="camp1">
              <div class="invalid-feedback">
                Please enter your shipping address.
              </div>
            </div>
            <div class="col-md-6">
              <label for="address">Qual a marca do aparelho ?</label>
              <input type="Tel" class="form-control" id="address" required name="camp2">
              <div class="invalid-feedback">
                Please enter your shipping address.
              </div>
              

            </div>
            
          </div>
          <label for="address">Quando foi a última manutenção ?</label>
          <input type="Tel" class="form-control" id="address" required name="camp3">
          <div class="invalid-feedback">
            Please enter your shipping address.
          </div>
        </div>
        <div class="mb-3">
          <label for="address">Quando o aparelho foi comprado ?</label>
          <input type="text" class="form-control" id="address" required name="camp4">
          <div class="invalid-feedback">
            Please enter your shipping address.
          </div>
        </div>
        <div class="mb-3">
          <label for="address">O aparelho que já sofreu mudanças em manutenção ?</label>
          <input type="text" class="form-control" id="address" required name="camp5">
          <div class="invalid-feedback">
            Please enter your shipping address.
          </div>
        </div>
        <div class="mb-3">
          <label for="address">Quando o aparelho começou apresentar o problema ?</label>
          <input type="text" class="form-control" id="address" required name="camp6" >
          <div class="invalid-feedback">
            Please enter your shipping address.
          </div>
        </div>
        
        <div class="mb-3">
          <label for="address">Abaixo, faça observações adicionais</label>
          <textarea class="form-control" id="address" required name="camp7"></textarea>
          <div class="invalid-feedback">
            Please enter your shipping address.
          </div>
        </div>


        

        <hr class="mb-4">
        <button class="btn btn-primary btn-lg btn-block" type="submit" name="cads">Cadastrar</button>
      </form>
    </div>
  </div><!--fim div row-->
</div><!--fim div container-->
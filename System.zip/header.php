 <?php
      session_start();

  if(!isset($_SESSION['logado'])):
    header("Location: login/login.php ");
  endif;
      include_once "classes/acesso.php";

    ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Administração</title>

    <link rel="canonical" href="estilo/css/dashboard/">
    <!-- Bootstrap core CSS -->
    <link href="estilo/css/bootstrap.min.css" rel="stylesheet">
    <link href="estilo/css/dashboard.css" rel="stylesheet">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script>window.jQuery || document.write('<script src="../assets/js/vendor/jquery.slim.min.js"><\/script>')</script><script src="estilo/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.9.0/feather.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script>
        <script src="estilo/js/dashboard.js"></script>

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
   
  </head>
  <body>
   

   
     <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
      <a class="navbar-brand col-md-3 col-lg-2 mr-0 px-3" href="adm.php">Mex Climatização</a>
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-toggle="collapse" data-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <span class="form-control form-control-dark w-100"><?php echo "Olá, ".$_SESSION['nome'];?></span>
        <ul class="navbar-nav px-3">
                    <li class="nav-item text-nowrap">
            
            <a class="nav-link" href="login/logout.php">Sair</a>
          </li>
        </ul>
      </nav>
     <div class="container-fluid">
      <div class="row">

          <nav id="sidebarMenu" class="col-md-2 col-lg-2 d-md-block bg-light sidebar collapse">
          <div class="sidebar-sticky pt-3">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="?pagina=agenda">
                  <img src="img/book.svg" style=" height: 16px; width: 16px;">
                  Agenda <span class="sr-only"></span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="?pagina=clientes">
                  <img src="img/people.svg" style=" height: 16px; width: 16px;">
                  Clientes
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="?pagina=servicos">
                  <img src="img/person.svg" style=" height: 16px; width: 16px;">
                  Serviços
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="?pagina=relatorios">
                  <img src="img/server.svg" style=" height: 16px; width: 16px;">
                  Relatórios de Serviços
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="?pagina=precos">
                  <img src="img/cash-stack.svg" style=" height: 16px; width: 16px;">
                  Preços de Serviços
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="?pagina=equipamentos">
                  <img src="img/gear.svg" style=" height: 16px; width: 16px;">
                  Equipamentos
                </a>
              </li>
            </ul>

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span></span>
              <a class="d-flex align-items-center text-muted" href="#" aria-label="Add a new report">
                <span data-feather="plus-circle"></span>
              </a>
            </h6>
            
          </div>
        </nav>



        

        
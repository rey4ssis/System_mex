<?php 
class Usuarios extends Conexao{

	public $nome;
	public $email;
	public $senha;
	public $tipo_usuario;

	public function setNome($nome)
	{
	 $this->nome= $nome;
	}
	public function getNome()
	{
		return $this->nome;
	}

	public function setEmail($email)
	{
		$this->email= $email;
	}
	public function getEmail()
	{
		return $this->email;
	}

	public function setSenha($senha)
	{
	 $this->senha= $senha;
	}
	public function getSenha()
	{
		return $this->senha;
	}
	public function setTipo_usuario($tipo_usuario)
	{
	 $this->tipo_usuario= $tipo_usuario;
	}
	public function getTipo_usuario()
	{
		return $this->tipo_usuario;
	}
	
	
	//logar no sistema
	public function cadastrar(){ 
		$pdo    = parent::getDB();		
		$cad = $pdo->prepare("INSERT INTO usuarios(nome, email, senha) VALUES(?, ?, ?) ");		
		$cad->bindValue(1  , $this->x1 );	
		$cad->bindValue(2  , $this->x2);	
		$cad->bindValue(3  , md5($this->x3));	
		$cad->execute();
		if($cad->rowCount() > 0):
			return true;
		else:
			return false;		
		endif;	
		
	}
	

	
	
	
	public static function MostrarClientes(){ 
		$pdo    = parent::getDB();		
		$select = $pdo->prepare("SELECT * FROM  usuarios ORDER BY nome");	
		$select->execute();
		if($select->rowCount() > 0)://verifica se é administrador
			echo '
				<table border="1" width="600">
					<tr>
						<td>ID</td>
						<td>Nome</td>
						<td>E-mail</td>
						<td align="center">Editar</td>
						<td align="center">Excluir</td>
					</tr>
			';
		 	while($x = $select->fetch(PDO::FETCH_OBJ)):
				echo "
					<tr>
						<td>$x->id</td>
						<td>$x->nome</td>
						<td>$x->email</td>
						<td align='center'><a href='editarUser.php?id=$x->id'>E</a></td>
						<td align='center'>X</td>
					</tr>
				";
			endwhile;
			echo '</table>';
		endif;	
		
	}
	
	
	
	public  function formEditar(){ 
		$pdo    = parent::getDB();		
		$select = $pdo->prepare("SELECT * FROM  usuarios WHERE id=$this->x1");	
		$select->execute();
		if($select->rowCount() > 0):
		 	while($x = $select->fetch(PDO::FETCH_OBJ)):
				echo "
							
					<form method='post'>
					  <p>Nome:<br>
						<input type='text' name='nome' value='$x->nome'>
					  </p>
					  <p>E-mail:<br>
						<input type='email' name='email' value='$x->email'>
					  </p>
					  <p>
						<input type='submit' name='ok' value='Atualizar'>
					  </p>
					</form>
				";
			endwhile;
		endif;	
		
	}
	
		
}
?>
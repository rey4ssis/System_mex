<?php 

abstract class Conexao{
	
	const USER = 'root';
	const PASS = '';
	
	private static $instance = null;
	
	private static function Conectar(){
	   try{
	   if(self::$instance == null):
	      $dsn = "mysql:host=localhost;dbname=system_mex";
		  self::$instance = new PDO($dsn,self::USER,self::PASS);
		  self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	   endif;
	   }catch (PDOException $e){
		   echo "Erro: ". $e->getMessage();	   
	   }
	   return self::$instance;	
	}
	
	protected static function getConectar(){
		
	   return self::conectar();
	}
}

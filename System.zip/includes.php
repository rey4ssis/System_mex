<?php

	include "classes/acesso.php";
	//include "classes/clientes.class.php";
	include "classes/conexao.class.php";
	//include "classes/servicos.class.php";
  <?php
 
  
    if(!isset($_SESSION['logado'])):
      header("Location: login/login.php ");
    endif;

  ?>
  <div class="col-md-12">
    <main role="main" class="col-md-8 ml-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <?php
        
           $pagina = isset($_GET['pagina']) ? $_GET['pagina'] : null;

           if (isset($_SESSION)):
            
           

            switch ($pagina) {
              case 'agenda':
                include 'agenda.php';
                break;
              case 'clientes':
                include 'clientes.php';
                break;
              case 'servicos':
                include 'servicos.php';
                break;

              case 'relatorios':
                include 'relatorios_servicos.php';
                break;
              case 'precos':
                include 'precos_servicos.php';
                break;

              case 'equipamentos':
                include 'equipamentos.php';
                break;
              case 'formulario':
                include 'formulario.php';
                break;

              
              default:
                
                break;
            }
          endif;
        ?>
             


        </div>
    </main>
  


   </div>
   
    

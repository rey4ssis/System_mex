<?php
session_start();
unset($_SESSION);
if (session_destroy()) {
	echo '<script>alert("Deslogado com sucesso!!.");</script>';
	
	header('Location: login.php');
 }

?>


